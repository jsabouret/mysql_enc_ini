# mysql_enc_ini
MySQL Database encrypted login information for automated tasks in Python
